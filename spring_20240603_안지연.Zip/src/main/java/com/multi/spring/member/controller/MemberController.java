package com.multi.spring.member.controller;

import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.multi.spring.member.model.dto.MemberDTO;
import com.multi.spring.member.service.MemberService;

@Controller
@RequestMapping("/member")
public class MemberController {

	private final MemberService memberService;

	public MemberController(MemberService memberService) {
		super();
		this.memberService = memberService;
	}

	@RequestMapping("/main")
	public String main() {
		return "redirect:/index.jsp";
	}

	@RequestMapping("/member")
	public void memberMain() {

	}

	@RequestMapping("/insert_form")
	public void memberInsert() {

	}

	@RequestMapping("/delete_form")
	public void membeDelete() {

	}

	@RequestMapping("/update_form")
	public void memberUpdate() {

	}

	@RequestMapping("/one_form")
	public void memberOne() {

	}

	@RequestMapping("/list")
	public void memberList() {

	}

	@PostMapping("/insert")
	public String insertMember(MemberDTO memberDTO, HttpSession session) throws Exception {

		memberService.insertMember(memberDTO);

		System.out.println("insert ==> " + memberDTO);
		session.setAttribute("msg", "회원가입성공");
		return "redirect:/member/member";

	}

	@GetMapping("/delete")
	public String deleteMember(String id, HttpSession session) throws Exception {

		memberService.deleteMember(id);

		session.setAttribute("msg", "회원삭제 성공");
		return "redirect:/member/member";

	}

	@PostMapping("/update")
	public String updateMember(MemberDTO memberDTO, HttpSession session) throws Exception {

		memberService.updateMember(memberDTO);

		System.out.println("update ==> " + memberDTO);
		session.setAttribute("msg", "회원 수정 성공");
		return "redirect:/member/member";

	}

	@GetMapping("/list")
	public void selectMemberList(HttpSession session, Model model) throws Exception {

		ArrayList<MemberDTO> list = memberService.selectMemberList();

		for (int i = 0; i < list.size(); i++) {

			System.out.println(list.get(i));

		}

		session.setAttribute("msg", "회원 리스트 호출 성공");

		model.addAttribute("list", list);

	}

	@GetMapping("/one")
	public void selectMember(HttpSession session, String id, Model model) throws Exception {

		MemberDTO memberDTO = memberService.selectMember(id);

		System.out.println(memberDTO);

		session.setAttribute("msg", "회원 호출 성공");

		model.addAttribute("dto", memberDTO);

	}

}
